package com.vecindario.backend

fun main() { println("Servidor iniciado") }